return {
  -- _default = "FALLBACK",
  SERVER = { --
    CHARACTER = 'SECPASSWORD', --
  }, --
  Rath = { --
    Myfancychar = 'password1234', --
    ['xkcd'] = 'bestsite1234', --
  }, --
}
