return {
  -- _defaultPassword = 'PASSWORD',--
  accounts = {
    ['ACCOUNT1'] = {'PASSWORD', 'SEKPASSWORD'}, --
    ['ACCOUNT2'] = 'PASSWORD', --
  }, --
  [1] = {
    _title = "test",
    {
      acc = 'ACCOUNT', --
      srv_sel = 'SERVER', --
      chars = {
        SERVER = {
          'CHARACTER/NOTE', -- preselect
          'CHARACTER/NOTE',
        }, --
      }, --
      note = 'NOTE',
    }, -- login account
    {acc = 'ACCOUNT', srv_sel = 'SERVER'}, -- login account
    {acc = 'ACCOUNT', srv = 'SERVER', char = 'CHARACTER', note = 'NOTE'}, -- login to game
    {acc = 'ACCOUNT', srv = 'SERVER', note = 'NOTE'}, -- login to character select
  }, --
  [2] = {}, --
  [3] = {}, --
  [4] = {{acc = 'ACCOUNT', srv_sel = 'SERVER'}}, --
  [5] = {}, --
  [6] = {}, --
  [7] = {{acc = 'ACCOUNT', srv_sel = 'SERVER'}}, --
  [10] = {{acc = 'ACCOUNT', srv_sel = 'SERVER'}}, --
  [11] = {{acc = 'ACCOUNT', srv_sel = 'SERVER'}}, --
}
