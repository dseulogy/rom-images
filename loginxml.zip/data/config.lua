return { --
  debug = false, --
  channel = 1, --
  show_account_info = true, --

  account_single_click = false,--
  account_force_show = false,--
  account_use_slider = true, --
  account_use_list = true, --
  account_columns = 5,--
  account_page = 1,--

  server_single_click = false,--

  character_single_click = false,--
  character_login_single = true, --
  character_nologin_ctrl = true, --
  character_sort = true, --
}
