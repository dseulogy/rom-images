local me = {
  maxEntries = 100, --
  data = {}, --
}

function lprint(formatter, ...)
  table.insert(me.data, 1, {{text = string.format(tostring(formatter), ...)}})
  me.data[me.maxEntries] = nil
  if LoginDebugFrame_list and LoginDebugFrame_list.update then
    LoginDebugFrame_list:update()
  end
end
function ldebug(text, ...)
  table.insert(me.data, 1, {{text = text, tooltip = {...}}})
  me.data[me.maxEntries] = nil
  if LoginDebugFrame_list and LoginDebugFrame_list.update then
    LoginDebugFrame_list:update()
  end
end

function me.onLoad(this)
  if login.config.debug then
    this:Show()
  else
    this:Hide()
  end
  local frameName = this:GetName() .. '%s'
  local list = _G[frameName:format('_list')]
  local data = {
    col = {300}, --
    fn = { --
      callback = me.callback, --
      onEnter = me.onEnter, --
      onLeave = me.onLeave, --
    }, --
    align = {2},
  }
  list:init(data)
  _G[frameName:format('_cmd')]:SetPlaceholder('command')
end

-- ! ==============================================================
-- ! ===================== list callbacks =========================
-- ! ==============================================================
function me.callback()
  return me.data, {'debugger'}, 1
end

function me.onEnter(_, index, _, row)
  LoginTooltip:ClearAllAnchors()
  LoginTooltip:SetAnchor('TOPLEFT', 'BOTTOMLEFT', row, 10, 0)
  local data = me.data[index][1]
  LoginTooltip:SetText(tostring(data.text))
  for _, txt in ipairs(data.tooltip or {}) do
    LoginTooltip:AddLine(tostring(txt))
  end
end
function me.onLeave()
  LoginTooltip:Hide()
end
_G['LoginDebug'] = me
